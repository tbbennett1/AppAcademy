module.exports = {
  MONGO_URI: "mongodb+srv://dbUser:uDximZeNJPiP8ea7@cluster0-stiad.mongodb.net/test?retryWrites=true&w=majority",
  secretOrPrivateKey: "secret"
};
