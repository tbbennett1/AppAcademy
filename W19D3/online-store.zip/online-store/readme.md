{
  "data": {
    "categories": [
      {
        "id": "5d950df608d4c1f9997b6593",
        "name": "Drink",
        "products": []
      },
      {
        "id": "5d950dfb08d4c1f9997b6594",
        "name": "Food",
        "products": []
      }
    ]
  }
}