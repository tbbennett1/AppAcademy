// server/models/index.js

require("./User");
require("./Category");
require("./Product");